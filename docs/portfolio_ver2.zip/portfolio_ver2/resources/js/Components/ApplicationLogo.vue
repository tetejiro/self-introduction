<script setup>
    let icon = '/favicon.ico'
</script>

<template>
    <img :src="icon">
</template>
