<script setup>
</script>

<template>
  <div class="h-screen text-center">
    <div>
      <div>エラーが起きました。</div>
      <div>開発者にエラーを通知しました。</div>
      <div>お手数をおかけしますが、もう一度やり直してください。</div>
      <div class="text-blue-800 mx-auto w-fit"><a href="/dashboard">トップページへもどる</a></div>
    </div>
  </div>
</template>